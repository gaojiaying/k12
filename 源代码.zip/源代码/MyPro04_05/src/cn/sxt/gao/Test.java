package cn.sxt.gao;

import  cn.sxt.oo.User;   //��ʾ������User��

import  java.util.Date;
import  java.sql.*;

import static  java.lang.Math.*;

public class Test {
		public static void main(String[] args) {
//			cn.sxt.oo.User   user = new cn.sxt.oo.User();
			User  user  = new  User();
			String  str;
			
			java.util.Date  date  = new java.util.Date(); 
			
			System.out.println(Math.PI); 
			System.out.println(PI);
			
			
		}
}
